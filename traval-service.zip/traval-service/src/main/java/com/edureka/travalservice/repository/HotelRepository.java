/**
 * 
 */
package com.edureka.travalservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edureka.travalservice.entity.HotelEntity;

/**
 * @author nmask
 *
 */
public interface HotelRepository extends JpaRepository<HotelEntity, Long> {

}

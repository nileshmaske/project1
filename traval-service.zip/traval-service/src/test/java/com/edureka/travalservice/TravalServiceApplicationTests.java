package com.edureka.travalservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

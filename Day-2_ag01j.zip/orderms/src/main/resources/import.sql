insert into order_data (name) values ('iPhone');
insert into order_data (name) values ('Nexus');
insert into order_data (name) values ('Samsung');
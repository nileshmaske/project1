insert into user (name) values ('Bandaru');
insert into user (name) values ('Geetha');
insert into user (name) values ('Joyce');
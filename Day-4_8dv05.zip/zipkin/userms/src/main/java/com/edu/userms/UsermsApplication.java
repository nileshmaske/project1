package com.edu.userms;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

@SpringBootApplication
@RestController
@EnableHystrix
@EnableFeignClients
public class UsermsApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(UsermsApplication.class);

	@Autowired
	private OrdermsFeignClientConfig feignClient;
	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/hello")
	public String getHello() {
		LOGGER.info("********");
		LOGGER.info("this is a sample app");
		return feignClient.getHello();
	}

	@GetMapping("/orders-client")
	@HystrixCommand(fallbackMethod = "getFromFallback")
	public Object getUsersFromServer() {
		System.out.println("RestTemplate");
		LOGGER.info("********");
//		return restTemplate.getForObject("http://localhost:8080/users", Object.class);
		return restTemplate.getForObject("http://orderms/orders", Object.class);
	}

	@GetMapping("/users/orders")
	@HystrixCommand(fallbackMethod = "getFromFallback",
			commandProperties = {
					@HystrixProperty(
							name="execution.isolation.thread.timeoutInMilliseconds", value="3000")})
	public Object getAllOrders() {
		LOGGER.info("********");
		System.out.println("FeignClient");
		Object allOrders = feignClient.getAllOrders();
		return allOrders;
	}

	public Object getFromFallback() {
		return Arrays.asList("one", "two");
	}


	public static void main(String[] args) {
		SpringApplication.run(UsermsApplication.class, args);
	}

}

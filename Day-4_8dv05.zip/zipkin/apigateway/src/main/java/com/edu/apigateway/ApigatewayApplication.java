package com.edu.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApigatewayApplication {

	/*@Bean
	public RouteLocator myRoutes(RouteLocatorBuilder builder) {
		System.out.println("*****************");
		System.out.println("*****************");
		return builder.routes()
				.route(p -> p
						.path("/orders/**")
						.filters(f -> f.addRequestHeader("Hello", "World"))
						.uri("http://localhost:8082/orders"))
				.build();
	}*/

	public static void main(String[] args) {
		SpringApplication.run(ApigatewayApplication.class, args);
	}

}

package com.edureka.confgserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfgServerApplicationTests {

	@Test
	void contextLoads() {
	}

}

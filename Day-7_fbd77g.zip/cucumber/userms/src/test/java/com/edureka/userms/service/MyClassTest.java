package com.edureka.userms.service;

import static org.junit.jupiter.api.Assertions.*;

class MyClassTest {

}
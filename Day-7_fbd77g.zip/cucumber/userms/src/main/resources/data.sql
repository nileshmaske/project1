insert into user (name) values ('AbdulRahman');
insert into user (name) values ('Bala');
insert into user (name) values ('Preeti');
insert into user (name) values ('Venkatesh');
package com.edureka.userms.service;

public class MyClass {

    public int enrich(int n) {
        return n + 2;
    }
}

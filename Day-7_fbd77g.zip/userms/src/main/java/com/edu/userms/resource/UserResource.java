package com.edu.userms.resource;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.edu.userms.config.OrdermsClient;
import com.edu.userms.model.User;
import com.edu.userms.repo.UserRepo;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@RestController
public class UserResource {
	
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserResource.class);
	
	@Autowired
	private UserRepo repo;
	@Autowired
	private OrdermsClient ordermsClient;
	
	@GetMapping("/hello")
	public String getHello() {		
		return "Hello Edureka!";
	}
	
	@GetMapping("/users")
	public List<User> getUsers() {		
		return repo.findAll();
	}
	
	@PostMapping("/users")
	public User createUser(@RequestBody User user) {
		User newUser = repo.save(user);
		return newUser;
	}
	
	@GetMapping("/users-orders")
	@HystrixCommand(fallbackMethod = "getFromFallback",
			commandProperties = {
					@HystrixProperty(
							name="execution.isolation.thread.timeoutInMilliseconds", value="3000")})
	public Object getOrders() {		
		LOGGER.info("calling orderms");
		// RestTemplate.exchange
//		Autowire restTemplate
//		restTemplate.getForObject("http://orderms/orders", Object.class);
		return ordermsClient.getAllOrders();
	}
	
	public Object getFromFallback() {	
		return Arrays.asList("one", "two");
	}

	
	
	
	
	
	
	
	
	
	
}

package com.edu.userms.some;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

//@Component
//@Service // Service class business logic
//@RestController // API RESTful
//@Controller // UI(HTML)
//@Repository // DB
//@Configuration // create beans
public class AnotherClass {

}

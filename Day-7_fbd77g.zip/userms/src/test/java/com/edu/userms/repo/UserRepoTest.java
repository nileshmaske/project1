package com.edu.userms.repo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import com.edu.userms.model.User;

@DataJpaTest
public class UserRepoTest {
	
	@Autowired
	private TestEntityManager testEntityManager;
	@Autowired
	private UserRepo repo;
	
	@Test
	void findUsers() {
		User user = new User();
		user.setName("abc");
		testEntityManager.persist(user);
		testEntityManager.flush();
		List<User> actualUsers = repo.findAll();
		int size = actualUsers.size();
		assertEquals(4, size);
	}
	
	

}

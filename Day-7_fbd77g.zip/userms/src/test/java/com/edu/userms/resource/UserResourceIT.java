package com.edu.userms.resource;

import java.util.List;

import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import com.edu.userms.model.User;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations ="classpath:application-test.properties")
public class UserResourceIT {
	@LocalServerPort
	private int port;
	
	@Autowired
	private TestRestTemplate testRestTemplate;
	
	@Test
	void getAllUsers() {
		String url = "http://localhost:" + port + "/users";
		ResponseEntity<List<User>> response = testRestTemplate.exchange(url,  HttpMethod.GET, null, new ParameterizedTypeReference<List<User>>() {
		});
		
		MatcherAssert.assertThat(response.getStatusCode(), CoreMatchers.equalTo(HttpStatus.OK));
		List<User> usersList = response.getBody();
		MatcherAssert.assertThat(3, CoreMatchers.equalTo(usersList.size()));
	}
	
	@Test
	void saveUser() {
		User user = new User();
		user.setName("abc");
		HttpEntity<User> httpEntity = new HttpEntity<>(user);
		String url = "http://localhost:" + port + "/users";
		testRestTemplate.postForEntity(url, httpEntity, User.class);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

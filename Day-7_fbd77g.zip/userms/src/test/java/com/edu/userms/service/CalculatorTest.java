package com.edu.userms.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class CalculatorTest {
	@Mock
	private MyClass myClassMock;
	
	@Test
	void add_solitary() {
		MockitoAnnotations.initMocks(this);
		Mockito.when(myClassMock.enrich(ArgumentMatchers.anyInt()))
				.thenReturn(5);
		Calculator calculator = new Calculator(myClassMock);
		
		int actualResult = calculator.add(2, 3);
		assertEquals(10, actualResult);
	}

	
	@Test
	void add_sociable() {
		MyClass myClass = new MyClass();
		Calculator calculator = new Calculator(myClass);
		
		int actualResult = calculator.add(2, 3);
		assertEquals(9, actualResult);
	}

}

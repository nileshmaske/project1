package com.edu.lowercasestreamms;

import java.util.function.Function;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class LowercaseStreammsApplication {
	
	@Bean
	public Function<String, String> toLowercase() {
		return s -> {
			System.out.println("lowercase receives: " + s);
			// db.save, processing
			return s.toLowerCase();
		};
	}

	public static void main(String[] args) {
		SpringApplication.run(LowercaseStreammsApplication.class, args);
	}

}

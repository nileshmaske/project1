package com.edu.uppercasestreamms;

import java.util.function.Function;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class UppercaseStreammsApplication {
	
	@Bean
	public Function<String, String> toUppercase() {
		return s -> {
			System.out.println("uppercase receives: " + s);
			// db.save, processing
			return s.toUpperCase();
		};
	}

	public static void main(String[] args) {
		SpringApplication.run(UppercaseStreammsApplication.class, args);
	}

}

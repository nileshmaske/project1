package com.edu.uppercasestreamms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UppercaseStreammsApplicationTests {

	@Test
	void contextLoads() {
	}

}

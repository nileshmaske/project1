package com.edu.mongodbms.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.edu.mongodbms.model.Payment;

public interface PaymentRepo extends MongoRepository<Payment, String> {
	

}

/*
package com.edureka.sagaorchestrator.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class MyStateServiceTest {
    @Autowired
    private MyStateService myStateService;

    @Test
    public void test_initiate() {
        System.out.println("starting test");
        myStateService.initiateStateE1();
        System.out.println("E2-Start");
        myStateService.stateE2();
        System.out.println("E3-Start");
        myStateService.stateE3();
        System.out.println("ending test");
    }

}*/

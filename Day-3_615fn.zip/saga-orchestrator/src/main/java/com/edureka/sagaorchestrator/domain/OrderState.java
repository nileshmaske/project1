package com.edureka.sagaorchestrator.domain;

public enum OrderState {
    NEW, AIRLINE, HOTEL, COMPLETED, CANCELLED, FAILED
}

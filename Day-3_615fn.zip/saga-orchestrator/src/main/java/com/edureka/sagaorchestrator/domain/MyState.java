package com.edureka.sagaorchestrator.domain;

public enum MyState {
    SI, S1, S2, S3, SF
}

package com.edureka.sagaorchestrator.domain;

public enum OrderStatus {
    NEW, PENDING, COMPLETED, CANCELLED, AIRLINE_SUCCESS, AIRLINE_FAILED, HOTEL_SUCCESS, HOTEL_FAILED, FAILED
}

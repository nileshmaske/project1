package com.edu.mqserver;

import javax.jms.ConnectionFactory;
import javax.jms.Queue;
import javax.jms.Topic;

import org.apache.activemq.command.ActiveMQQueue;
import org.apache.activemq.command.ActiveMQTopic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
@EnableJms
public class MqServerApplication {
	
	@Autowired
	private JmsTemplate jmsTemplateQueue;
	@Autowired
	private JmsTemplate jmsTemplateTopic;
	
	@Autowired
	private Queue queue_1;
	@Autowired
	private Topic topic_2;
	
	
	@GetMapping("/messages/{mes}")
	public String publish(@PathVariable String mes) {
		System.out.println("REST Message received: " + mes);
		
		jmsTemplateQueue.convertAndSend(queue_1, "Q-" + mes);
		jmsTemplateTopic.convertAndSend(topic_2, "T-" + mes);
		
		return mes;
	}
	
	
	
	@Bean
	public Queue queue_1() {
		return new ActiveMQQueue("queue_1");
	}
	
	@Bean
	public Topic topic_2() {
		return new ActiveMQTopic("topic_2");
	}
	
	
	
	
	@Bean
	public DefaultJmsListenerContainerFactory jmsTemplateTopic(
			DefaultJmsListenerContainerFactoryConfigurer configurer,
			ConnectionFactory connectionFactory) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		configurer.configure(factory, connectionFactory);
		// listens to Topic
		factory.setPubSubDomain(true);
		
		return factory;
	}

	public static void main(String[] args) {
		SpringApplication.run(MqServerApplication.class, args);
	}

}

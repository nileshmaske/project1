package com.edu.mqclient1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MqClient1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.edu.mqclient2;

import javax.jms.ConnectionFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;

@SpringBootApplication
public class MqClient2Application {
	
	@JmsListener(destination = "queue_1")
	public void listenToQueue(String message) {
		System.out.println("Q-Received: " + message);
	}
	
	@JmsListener(destination = "topic_2", containerFactory = "topicListener")
	public void listenToTopic(String message) {
		System.out.println("Topic-Received: " + message);
	}
	
	@Bean
	public DefaultJmsListenerContainerFactory topicListener(
			DefaultJmsListenerContainerFactoryConfigurer configurer,
			ConnectionFactory connectionFactory) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		configurer.configure(factory, connectionFactory);
		// listens to Topic
		factory.setPubSubDomain(true);
		
		return factory;
	}

	public static void main(String[] args) {
		SpringApplication.run(MqClient2Application.class, args);
	}

}
